<?php
/**
 * Albanian language file
 *
 * @author Leonard Elezi leonard.elezi@depinfo.info
 */
$lang['menu']                  = 'Menaxhuesi Rikthimit';
$lang['filter']                = 'Kërko faqe me spam';
$lang['revert']                = 'Rikthe faqet e përzgjedhura';
$lang['reverted']              = '%s u rikthye në rishikimin %s';
$lang['removed']               = '%s u hoq';
$lang['revstart']              = 'Proçesi i rikthimit filloi. Kjo mund të zgjasë për një kohë të gjatë. Nëse koha e skriptit mbaron para përfundimit, atëherë rikthimi duhet të bëhet me copa të vogla.';
$lang['revstop']               = 'Proçesi i rikthimit mbaroi me sukses.';
$lang['note1']                 = 'Shënim: në këtë kërkim bëhet dallim midis gërmave kapitale dhe gërmave të vogla.';
$lang['note2']                 = 'Shënim: faqja do të rikthehet në versionin e fundit që nuk përmban term-in spam të dhënë <i>%s</i>.';
