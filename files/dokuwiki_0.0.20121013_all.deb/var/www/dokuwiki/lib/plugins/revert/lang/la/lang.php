<?php
/**
 * Latin language file
 *
 * @author Massimiliano Vassalli <vassalli.max@gmail.com>
 */
$lang['menu']                  = 'Restituendi administrator';
$lang['filter']                = 'Malas paginas quaerere';
$lang['revert']                = 'Electas paginas restituere';
$lang['reverted']              = '%s restitutur ut %s recenseas';
$lang['removed']               = '%s deletur';
$lang['revstart']              = 'Restitutio agens. Hic multo tempore agere potest. Si nimium tempus transit, manu restituis.';
$lang['revstop']               = 'Restitutio feliciter perfecta.';
$lang['note1']                 = 'Caue: litteras maiores et minores discernit';
$lang['note2']                 = 'Caue: pagina in recentiori forma sine malis uerbis "<i>%s</i>" restituetur';
