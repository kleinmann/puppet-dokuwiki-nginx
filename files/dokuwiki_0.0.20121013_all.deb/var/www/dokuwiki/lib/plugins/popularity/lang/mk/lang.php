<?php
/**
 * Macedonian language file
 *
 * @author Dimitar Talevski <dimi3.14@gmail.com>
 */
