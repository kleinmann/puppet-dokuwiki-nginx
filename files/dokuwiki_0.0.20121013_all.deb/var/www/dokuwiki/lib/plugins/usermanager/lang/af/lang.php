<?php
/**
 * Afrikaans language file
 *
 */
$lang['user_pass']             = 'Wagwoord';
$lang['user_name']             = 'Regte Naam';
$lang['user_mail']             = 'E-pos';
$lang['edit']                  = 'Verander';
$lang['search']                = 'Soek';
$lang['start']                 = 'begin';
$lang['prev']                  = 'voorigste';
$lang['next']                  = 'volgende';
$lang['last']                  = 'einde';
