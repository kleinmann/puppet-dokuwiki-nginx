<?php
/**
 * Malay language file
 *
 * @author Markos
 */
