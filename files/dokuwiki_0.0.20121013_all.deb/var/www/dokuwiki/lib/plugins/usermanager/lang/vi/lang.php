<?php
/**
 * Vietnamese language file
 *
 */
